let text = '      hEwO    ';
text = text.trim();
console.log('longitud:', text.length);

if (text.length > 2) { console.log(text[1]); }

console.log('uppercase:', text.toUpperCase());
console.log('lowercase:', text.toLowerCase());