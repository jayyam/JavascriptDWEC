let numero_aleatorio = Math.floor(Math.random() * (76 - 10 + 1) + 10);
let r = 10;

let a = Math.PI * (r ** 2) + numero_aleatorio;
let b = 2 * Math.PI * r + numero_aleatorio;
let c = (4 / 3) * Math.PI * (r ** 3) + numero_aleatorio;