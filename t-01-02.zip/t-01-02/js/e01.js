let estado = null;
estado ??= true;
let a = estado ? 'No molestar' : 'Disponible';

console.log(a);