We would like to thank everyone who contributed to this library. If you find our library useful and wish to support as well, you can show your support via [GitHub Sponsors](https://github.com/sponsors/limonte)

Alternative ways for donations (PayPal, cryptocurrencies, etc.) are listed here: https://sweetalert2.github.io/#donations

Your contribution will be greatly appreciated!

# Our Donors

- **[STED (NSFW)](https://sextoyeducation.com/)** (116 EUR)

  > Extremely useful. Thanks SweetAlert2!

- **[PriceListo](https://www.pricelisto.com/)** (130 USD worth of BTC)

  > Love using SweetAlert2! Our JS popups finally look great and are super fun to use.

- **[LoveLoxy (NSFW)](https://loveloxy.com/)** (105 USD)

- **SebaEBC** (100 USD)

- **[Bingato (NSFW 18+)](https://bingato.com/)** (100 USD)

- **[NDCHost](https://www.ndchost.com/)** (100 USD)

  > Thank you for this great project!

- **[SheetJS LLC](https://sheetjs.com/)** (100 USD)

  > Great Work with SweetAlert2!

- **[STC (NSFW)](http://sextoycollective.com/)** (100 USD)

  > Love this! Thanks for making the Internet a prettier place.

- **[Unique-P GmbH](https://www.unique-p.ch/)** (100 CHF)

  > Great work guys! Awesome library, very helpful!

- **[@faalbane](https://github.com/faalbane)** (36 USD)

- **Germano Rizzo** (35 EUR)

  > Great job! I saved quite a few hours of work with this, and excellent quality!

- **[Jan Fässler](https://github.com/faessler)** (30 EUR)

  > Nice work! 👾

- **Ventsislav Radev** (23 EUR)

- **Isaiah Joshua M. Samonte** (25 USD)

  > Thank you very much for your work.

- **Danny Lankar** (25 USD)

  > You should be selling this product. Love it, thank you!

- **Johnny Lockhart** (25 USD)

- **Vivek Bhatnagar** (20 EUR)

  > Thanks for sweet-alert, I used it for a small charity project and it's awesome. Please accept our small token of thanks. God bless!

- **[Brand Lovely](https://www.brandlovely.com/)** (20 EUR)

- **Alex Frei** (20 EUR)

- **[iCrew Rowing](https://www.icrew.club/)** (20 USD)

  > SweetAlert2 is indeed "sweet". Glad I stumbled up it in a post on StackOverflow.

- **[VEI Hosting](http://www.veihosting.com/)** (20 USD)

- **Emil Kristensen** (15 EUR)

- **Benjamin James** (20 AUD)

- **Panayiotis Panayiotou** (10 GBP)

- **Alfredo Impera** (10 EUR)

- **Motim8 LLC** (10 EUR)

- **Ivan Zamecnik** (10 EUR)

- **Denis Veg** (10 EUR)

  > Thank you for all your amazing work on SWAL!

- **Daniel Seuffer** (10 EUR)

  > Thx for this very sweet alert!! And the continuous support. :-)

- **Morgan Touverey** (10 EUR)

  > From [@toverux](github.com/toverux) with love!

- **Jan Philip Steimel** (10 EUR)

  > thank you!

- **Patrik Kernstock** (10 EUR)

- **Jeff Keith** (10 EUR)

  > SweetAlert2 saved me tons of time.

- **Rick Hays** (10 USD)

- **TSD Technology, LLC** (10 USD)

  > Thank you for this awesome package.

- **Princenetwork** (300 THB)

  > Your work made me use less time for do some stuff about alert.

- **Alexey Popov** (5 EUR)

- **Rotem Lanyado** (5 EUR)

- **Julius Tens** (5 EUR)

- **Mauricio Robles Huerta** (5 EUR)

- **David Barber** (5 USD)

  > Thanks for SWAL love it!

- **[Michalis Tzikas](https://www.webhoster.gr)** (5 EUR)

  > Thank you very much for your great work

- **[Marco Franke](https://github.com/Disane87)** (5 EUR)

  > Thank you for this great development! Really love it! Discovered it years ago for a private projects and now we use this in our application at work :-)

- **Legoman99573** (0,20 EUR)

  > I dont have much, but I can say that SweetAlert2 is badass and have used it. Here is what I still have left in my paypal balance. Like to see more features in the future to play with.

- **[Gautier Dele](https://github.com/GautierDele)** (5 EUR)

  > Keep going, awesome job!

- **Elliot Ajcuc Chamale** (5 USD)

  > Hello! a contribution with your work, the best sweetalert2. Thank you

- **Mustafa Khader** (5 USD)

- **Quentin Le Doledec** (5 EUR)

- **[Cassiano Montanari](https://github.com/cassianomon)** (10 BRL)

- **Munsifali Rashid** (5 USD)

- **Mapcom Internet Technologies** (10 AUD)

- **Pawel Terebinski** (5 EUR)

- **iHoster** (3 EUR)

  > SweetAlert is very useful. It makes our web projects more beautiful! Thanks!

- **Singdavid Srun** (2 EUR)

- **Victor Felipe De Freitas** (10 BRL)

- **Diego Liz Arrazao** (5 BRL)

- **Lindauson Hazell** (5 EUR)

- **Quipro** (5 USD)

- **David Langheiter** (5 EUR)
